/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define B1_Pin GPIO_PIN_13
#define B1_GPIO_Port GPIOC
#define g_Pin GPIO_PIN_0
#define g_GPIO_Port GPIOC
#define f_Pin GPIO_PIN_1
#define f_GPIO_Port GPIOC
#define e_Pin GPIO_PIN_2
#define e_GPIO_Port GPIOC
#define d_Pin GPIO_PIN_3
#define d_GPIO_Port GPIOC
#define USART_TX_Pin GPIO_PIN_2
#define USART_TX_GPIO_Port GPIOA
#define USART_RX_Pin GPIO_PIN_3
#define USART_RX_GPIO_Port GPIOA
#define LD2_Pin GPIO_PIN_5
#define LD2_GPIO_Port GPIOA
#define c_Pin GPIO_PIN_4
#define c_GPIO_Port GPIOC
#define b_Pin GPIO_PIN_5
#define b_GPIO_Port GPIOC
#define GStart_Pin GPIO_PIN_0
#define GStart_GPIO_Port GPIOB
#define P1_Pin GPIO_PIN_1
#define P1_GPIO_Port GPIOB
#define P2_Pin GPIO_PIN_2
#define P2_GPIO_Port GPIOB
#define P2Counter0_Pin GPIO_PIN_12
#define P2Counter0_GPIO_Port GPIOB
#define P2Counter1_Pin GPIO_PIN_13
#define P2Counter1_GPIO_Port GPIOB
#define P2Counter2_Pin GPIO_PIN_14
#define P2Counter2_GPIO_Port GPIOB
#define P2Counter3_Pin GPIO_PIN_15
#define P2Counter3_GPIO_Port GPIOB
#define a_Pin GPIO_PIN_6
#define a_GPIO_Port GPIOC
#define dp_Pin GPIO_PIN_7
#define dp_GPIO_Port GPIOC
#define TMS_Pin GPIO_PIN_13
#define TMS_GPIO_Port GPIOA
#define TCK_Pin GPIO_PIN_14
#define TCK_GPIO_Port GPIOA
#define SWO_Pin GPIO_PIN_3
#define SWO_GPIO_Port GPIOB
#define P1Counter0_Pin GPIO_PIN_4
#define P1Counter0_GPIO_Port GPIOB
#define P1Counter1_Pin GPIO_PIN_5
#define P1Counter1_GPIO_Port GPIOB
#define P1Counter2_Pin GPIO_PIN_6
#define P1Counter2_GPIO_Port GPIOB
#define P1Counter3_Pin GPIO_PIN_7
#define P1Counter3_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
